package com.example.pipelinedetector;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class GraphActivity extends AppCompatActivity {

    // UI components
    private LineChart chart;
    private TextView txtFlowRate1, txtFlowRate2, txtFlowRate3;
    private TextView txtWarning;
    private Button btnViewState, btnDisconnect;
    private ImageButton btnBack;
    
    // Data
    private float[] flowRates = new float[3];
    private LineDataSet dataSet;
    private LineData lineData;
    
    // Simulated data for demo
    private static final float[] SENSOR_POSITIONS = {0.0f, 0.3f, 0.6f};
    private static final Random random = new Random();
    private static final int UPDATE_INTERVAL_MS = 1000;
    
    // Flag to simulate a leak for demo purposes
    private boolean simulateLeak = false;
    private int leakArea = 0;
    
    // Handler for periodic updates
    private final Handler handler = new Handler();
    private Runnable updateDataRunnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graph);
        
        // Initialize views
        chart = findViewById(R.id.lineChart);
        txtFlowRate1 = findViewById(R.id.txt_flow_rate_1);
        txtFlowRate2 = findViewById(R.id.txt_flow_rate_2);
        txtFlowRate3 = findViewById(R.id.txt_flow_rate_3);
        txtWarning = findViewById(R.id.txt_warning);
        btnViewState = findViewById(R.id.btn_view_state);
        btnDisconnect = findViewById(R.id.btn_disconnect);
        btnBack = findViewById(R.id.btn_back);
        
        // Initialize chart
        setupChart();
        
        // Set click listeners
        btnViewState.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openStateActivity();
            }
        });
        
        btnDisconnect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        
        // Initialize data and start updates
        initializeData();
        
        // Create the update runnable
        updateDataRunnable = new Runnable() {
            @Override
            public void run() {
                updateData();
                handler.postDelayed(this, UPDATE_INTERVAL_MS);
            }
        };
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        // Start periodic updates
        handler.post(updateDataRunnable);
    }
    
    @Override
    protected void onPause() {
        super.onPause();
        // Stop updates when activity is paused
        handler.removeCallbacks(updateDataRunnable);
    }
    
    private void setupChart() {
        // Configure chart appearance
        chart.getDescription().setEnabled(false);
        chart.setDrawGridBackground(false);
        chart.setDrawBorders(true);
        chart.setBorderColor(Color.LTGRAY);
        chart.setBorderWidth(1f);
        chart.setNoDataText("No data available");
        
        // Enable touch gestures
        chart.setTouchEnabled(true);
        chart.setDragEnabled(true);
        chart.setScaleEnabled(true);
        chart.setPinchZoom(true);
        
        // Configure X axis
        XAxis xAxis = chart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(0.3f);
        xAxis.setDrawGridLines(true);
        xAxis.setAxisMinimum(0f);
        xAxis.setAxisMaximum(0.6f);
        xAxis.setLabelCount(3);
        xAxis.setValueFormatter(new IndexAxisValueFormatter(
                new String[]{"Sensor 1", "Sensor 2", "Sensor 3"}));
        
        // Configure Y axis
        YAxis leftAxis = chart.getAxisLeft();
        leftAxis.setAxisMinimum(0f);
        leftAxis.setAxisMaximum(200000f);
        leftAxis.setDrawGridLines(true);
        leftAxis.setGranularity(25000f);
        
        YAxis rightAxis = chart.getAxisRight();
        rightAxis.setEnabled(false);
        
        // Set legend and other settings
        chart.getLegend().setEnabled(true);
        chart.animateX(750);
    }
    
    private void initializeData() {
        List<Entry> entries = new ArrayList<>();
        
        // Initialize with simulated data
        for (int i = 0; i < 3; i++) {
            // Start with normal flow rates
            flowRates[i] = 15.0f + random.nextFloat() * 2.0f;
            
            // Calculate pressure from flow rate
            float pressure = PipeLeakageDetector.calculatePressure(flowRates[i]);
            entries.add(new Entry(SENSOR_POSITIONS[i], pressure));
        }
        
        // Create the data set
        dataSet = new LineDataSet(entries, "Pipeline Pressure");
        dataSet.setColor(Color.parseColor("#7B1FA2")); // Purple color
        dataSet.setLineWidth(3f);
        dataSet.setDrawCircles(true);
        dataSet.setCircleColor(Color.parseColor("#7B1FA2"));
        dataSet.setCircleRadius(6f);
        dataSet.setDrawValues(false);
        dataSet.setMode(LineDataSet.Mode.LINEAR);
        
        // Add the data set to the chart
        lineData = new LineData(dataSet);
        chart.setData(lineData);
        chart.invalidate();
        
        updateFlowRateLabels();
    }
    
    private void updateData() {
        List<Entry> entries = new ArrayList<>();
        
        // Randomly decide whether to simulate a leak (for demonstration)
        if (random.nextInt(100) < 5 && !simulateLeak) {
            simulateLeak = true;
            leakArea = random.nextInt(2) + 1; // 1 or 2 (between sensors 1-2 or 2-3)
        } else if (random.nextInt(100) < 10 && simulateLeak) {
            simulateLeak = false;
            leakArea = 0;
        }
        
        // Update flow rates with some random variation
        for (int i = 0; i < 3; i++) {
            // Add small random variations to simulate sensor noise
            flowRates[i] += (random.nextFloat() - 0.5f) * 0.5f;
            
            // Keep within reasonable bounds
            if (flowRates[i] < 10.0f) flowRates[i] = 10.0f;
            if (flowRates[i] > 20.0f) flowRates[i] = 20.0f;
        }
        
        // If simulating a leak, adjust the flow rates appropriately
        if (simulateLeak) {
            if (leakArea == 1) {
                // Leak between sensors 1 and 2
                flowRates[1] -= 5.0f;
                flowRates[2] -= 5.0f;
            } else if (leakArea == 2) {
                // Leak between sensors 2 and 3
                flowRates[2] -= 5.0f;
            }
        }
        
        // Create entries from the flow rates (converted to pressure)
        for (int i = 0; i < 3; i++) {
            float pressure = PipeLeakageDetector.calculatePressure(flowRates[i]);
            entries.add(new Entry(SENSOR_POSITIONS[i], pressure));
        }
        
        // Update data set
        dataSet.clear();
        dataSet.setValues(entries);
        lineData.notifyDataChanged();
        chart.notifyDataSetChanged();
        chart.invalidate();
        
        // Update UI
        updateFlowRateLabels();
        checkForLeaks();
    }
    
    private void updateFlowRateLabels() {
        txtFlowRate1.setText(String.format("Sensor 1: %.2f L/min", flowRates[0]));
        txtFlowRate2.setText(String.format("Sensor 2: %.2f L/min", flowRates[1]));
        txtFlowRate3.setText(String.format("Sensor 3: %.2f L/min", flowRates[2]));
    }
    
    private void checkForLeaks() {
        int leakSection = PipeLeakageDetector.detectLeak(flowRates);
        
        if (leakSection > 0) {
            txtWarning.setVisibility(View.VISIBLE);
            String leakDescription = PipeLeakageDetector.getLeakDescription(leakSection);
            txtWarning.setText(leakDescription.toUpperCase());
        } else {
            txtWarning.setVisibility(View.GONE);
        }
    }
    
    private void openStateActivity() {
        Intent intent = new Intent(this, StateActivity.class);
        intent.putExtra("flow_rates", flowRates);
        intent.putExtra("leak_section", PipeLeakageDetector.detectLeak(flowRates));
        startActivity(intent);
    }
}