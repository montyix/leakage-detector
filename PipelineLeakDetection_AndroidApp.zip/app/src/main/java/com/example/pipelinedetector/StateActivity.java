package com.example.pipelinedetector;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class StateActivity extends AppCompatActivity {

    // UI components
    private ImageView imgPipeState;
    private TextView txtFlowRate1, txtFlowRate2, txtFlowRate3;
    private TextView txtWarning;
    private Button btnReturnToGraph, btnSaveReport;
    private ImageButton btnBack;
    
    // Data
    private float[] flowRates;
    private int leakSection;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_state);
        
        // Initialize views
        imgPipeState = findViewById(R.id.img_pipe_state);
        txtFlowRate1 = findViewById(R.id.txt_flow_rate_1);
        txtFlowRate2 = findViewById(R.id.txt_flow_rate_2);
        txtFlowRate3 = findViewById(R.id.txt_flow_rate_3);
        txtWarning = findViewById(R.id.txt_warning);
        btnReturnToGraph = findViewById(R.id.btn_return_to_graph);
        btnSaveReport = findViewById(R.id.btn_save_report);
        btnBack = findViewById(R.id.btn_back);
        
        // Get data from intent
        flowRates = getIntent().getFloatArrayExtra("flow_rates");
        leakSection = getIntent().getIntExtra("leak_section", 0);
        
        if (flowRates == null) {
            flowRates = new float[]{15.0f, 15.0f, 15.0f}; // Default values
        }
        
        // Update UI
        updateDisplay();
        
        // Set click listeners
        btnReturnToGraph.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        
        btnSaveReport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveReport();
            }
        });
        
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
    
    private void updateDisplay() {
        // Update flow rate labels
        txtFlowRate1.setText(String.format("Flow: %.2f L/min", flowRates[0]));
        txtFlowRate2.setText(String.format("Flow: %.2f L/min", flowRates[1]));
        txtFlowRate3.setText(String.format("Flow: %.2f L/min", flowRates[2]));
        
        // Update pipe state image based on leak section
        switch (leakSection) {
            case 0:
                imgPipeState.setImageResource(R.drawable.no_leak);
                txtWarning.setVisibility(View.GONE);
                break;
            case 1:
                imgPipeState.setImageResource(R.drawable.leak_1_2);
                txtWarning.setVisibility(View.VISIBLE);
                txtWarning.setText(getString(R.string.leak_section_1_2));
                break;
            case 2:
                imgPipeState.setImageResource(R.drawable.leak_2_3);
                txtWarning.setVisibility(View.VISIBLE);
                txtWarning.setText(getString(R.string.leak_section_2_3));
                break;
            case 3:
                imgPipeState.setImageResource(R.drawable.leak_multiple);
                txtWarning.setVisibility(View.VISIBLE);
                txtWarning.setText(getString(R.string.leak_multiple));
                break;
        }
    }
    
    private void saveReport() {
        // In a real app, this would save the current state to a database or file
        // For demo, just show a toast
        android.widget.Toast.makeText(this, R.string.report_saved, android.widget.Toast.LENGTH_SHORT).show();
    }
}