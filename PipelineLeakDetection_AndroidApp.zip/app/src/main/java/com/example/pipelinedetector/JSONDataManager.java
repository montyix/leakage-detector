package com.example.pipelinedetector;

import android.content.Context;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * This class manages the storage and retrieval of data in JSON format.
 * It handles saving leak events and retrieving history of leaks.
 */
public class JSONDataManager {
    private static final String TAG = "JSONDataManager";
    private static final String HISTORY_FILE = "leak_history.json";
    
    private final Context context;
    
    /**
     * Constructor
     * 
     * @param context The application context
     */
    public JSONDataManager(Context context) {
        this.context = context;
    }
    
    /**
     * Save a leak event to history
     * 
     * @param flowRates Array of flow rates
     * @param leakSection The section with a leak (0 = no leak)
     * @return True if saved successfully, false otherwise
     */
    public boolean saveLeakEvent(float[] flowRates, int leakSection) {
        try {
            // Load existing history
            JSONArray historyArray = loadHistory();
            
            // Create new event
            JSONObject event = new JSONObject();
            
            // Add timestamp
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
            Date now = new Date();
            
            event.put("date", dateFormat.format(now));
            event.put("time", timeFormat.format(now));
            
            // Add status and details
            if (leakSection > 0) {
                event.put("status", "LEAK DETECTED");
                event.put("details", PipeLeakageDetector.getLeakDescription(leakSection));
            } else {
                event.put("status", "NO LEAK");
                event.put("details", "Normal operation");
            }
            
            // Add flow rates
            JSONArray ratesArray = new JSONArray();
            for (float rate : flowRates) {
                ratesArray.put(rate);
            }
            event.put("flow_rates", ratesArray);
            
            // Add to history
            historyArray.put(event);
            
            // Save updated history
            return saveHistory(historyArray);
            
        } catch (JSONException e) {
            Log.e(TAG, "Error creating JSON event", e);
            return false;
        }
    }
    
    /**
     * Load the leak event history
     * 
     * @return JSONArray containing the history
     */
    public JSONArray loadHistory() {
        try {
            FileInputStream fis = context.openFileInput(HISTORY_FILE);
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader bufferedReader = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                sb.append(line);
            }
            bufferedReader.close();
            
            return new JSONArray(sb.toString());
        } catch (IOException | JSONException e) {
            Log.e(TAG, "Error loading history", e);
            return new JSONArray();
        }
    }
    
    /**
     * Save the history JSONArray to file
     * 
     * @param historyArray The history to save
     * @return True if saved successfully, false otherwise
     */
    private boolean saveHistory(JSONArray historyArray) {
        try {
            FileOutputStream fos = context.openFileOutput(HISTORY_FILE, Context.MODE_PRIVATE);
            fos.write(historyArray.toString().getBytes());
            fos.close();
            return true;
        } catch (IOException e) {
            Log.e(TAG, "Error saving history", e);
            return false;
        }
    }
    
    /**
     * Clear all history
     * 
     * @return True if cleared successfully, false otherwise
     */
    public boolean clearHistory() {
        return saveHistory(new JSONArray());
    }
    
    /**
     * Get the history as a list of maps for easier display
     * 
     * @return List of map entries with date, time, status, and details
     */
    public List<java.util.Map<String, String>> getHistoryList() {
        List<java.util.Map<String, String>> result = new ArrayList<>();
        
        try {
            JSONArray historyArray = loadHistory();
            
            for (int i = 0; i < historyArray.length(); i++) {
                JSONObject event = historyArray.getJSONObject(i);
                
                java.util.Map<String, String> item = new java.util.HashMap<>();
                item.put("date", event.getString("date"));
                item.put("time", event.getString("time"));
                item.put("status", event.getString("status"));
                item.put("details", event.getString("details"));
                
                result.add(item);
            }
        } catch (JSONException e) {
            Log.e(TAG, "Error parsing history", e);
        }
        
        return result;
    }
}