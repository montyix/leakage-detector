package com.example.pipelinedetector;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_ENABLE_BT = 1;
    private static final int REQUEST_PERMISSIONS = 2;
    
    private BluetoothAdapter bluetoothAdapter;
    private TextView statusTextView;
    private Button connectButton, viewGraphButton, viewHistoryButton;
    private ImageView logoImageView;
    
    private boolean isConnected = false;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        // Initialize views
        statusTextView = findViewById(R.id.txt_status);
        connectButton = findViewById(R.id.btn_connect);
        viewGraphButton = findViewById(R.id.btn_view_graph);
        viewHistoryButton = findViewById(R.id.btn_view_history);
        logoImageView = findViewById(R.id.logo);
        
        // Initialize Bluetooth adapter
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        
        // Check if Bluetooth is available
        if (bluetoothAdapter == null) {
            statusTextView.setText(R.string.bluetooth_not_available);
            connectButton.setEnabled(false);
            return;
        }
        
        // Set click listeners
        connectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkPermissionsAndConnect();
            }
        });
        
        viewGraphButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGraphActivity();
            }
        });
        
        viewHistoryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openHistoryActivity();
            }
        });
    }
    
    @Override
    protected void onStart() {
        super.onStart();
        
        // Enable Bluetooth if not enabled
        if (bluetoothAdapter != null && !bluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                requestBluetoothPermissions();
                return;
            }
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
        }
    }
    
    private void checkPermissionsAndConnect() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
            requestBluetoothPermissions();
        } else {
            connectToDevice();
        }
    }
    
    private void requestBluetoothPermissions() {
        ActivityCompat.requestPermissions(this,
                new String[]{
                        Manifest.permission.BLUETOOTH,
                        Manifest.permission.BLUETOOTH_ADMIN,
                        Manifest.permission.BLUETOOTH_CONNECT,
                        Manifest.permission.BLUETOOTH_SCAN
                },
                REQUEST_PERMISSIONS);
    }
    
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSIONS) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            
            if (allGranted) {
                connectToDevice();
            } else {
                Toast.makeText(this, "Bluetooth permissions required", Toast.LENGTH_SHORT).show();
            }
        }
    }
    
    private void connectToDevice() {
        // On real app, open Bluetooth device selection activity
        // For demo, simulate connection
        isConnected = true;
        statusTextView.setText("Connected to Pipeline Sensor");
        connectButton.setText("Disconnect");
        viewGraphButton.setEnabled(true);
        
        // Update UI
        connectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                disconnectFromDevice();
            }
        });
        
        // Change icon to no_leak
        logoImageView.setImageResource(R.drawable.no_leak);
    }
    
    private void disconnectFromDevice() {
        isConnected = false;
        statusTextView.setText("Not connected");
        connectButton.setText("Connect to Device");
        viewGraphButton.setEnabled(false);
        
        // Reset click listener
        connectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkPermissionsAndConnect();
            }
        });
    }
    
    private void openGraphActivity() {
        if (isConnected) {
            Intent intent = new Intent(this, GraphActivity.class);
            startActivity(intent);
        } else {
            Toast.makeText(this, "Please connect to a device first", Toast.LENGTH_SHORT).show();
        }
    }
    
    private void openHistoryActivity() {
        Intent intent = new Intent(this, HistoryActivity.class);
        startActivity(intent);
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_ENABLE_BT) {
            if (resultCode == RESULT_OK) {
                statusTextView.setText(R.string.bluetooth_enabled);
            } else {
                statusTextView.setText(R.string.bluetooth_not_enabled);
                Toast.makeText(this, "Bluetooth must be enabled to use this app", Toast.LENGTH_SHORT).show();
            }
        }
    }
}