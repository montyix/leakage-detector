package com.example.pipelinedetector;

/**
 * PipeLeakageDetector contains the core algorithm for detecting leakages
 * in the pipeline using Bernoulli's equation.
 */
public class PipeLeakageDetector {

    // Constants
    private static final float GRAVITY = 9.81f; // m/s²
    private static final float DENSITY = 1000.0f; // kg/m³ (water density)
    private static final float PIPE_DIAMETER = 0.02f; // m (2 cm)
    private static final float PIPE_AREA = (float) (Math.PI * Math.pow(PIPE_DIAMETER / 2, 2));
    
    // Sensor positions (in meters)
    private static final float[] SENSOR_POSITIONS = {0.0f, 0.3f, 0.6f};
    
    // Threshold for leak detection (percentage)
    private static final float LEAK_THRESHOLD = 10.0f;
    
    /**
     * Calculate pressure from flow rate
     * using Bernoulli's equation: P = P₀ - 0.5 * ρ * v²
     * 
     * @param flowRate Flow rate in L/min
     * @return Pressure in Pa
     */
    public static float calculatePressure(float flowRate) {
        // Convert L/min to m³/s
        float flowRateM3S = flowRate / (60.0f * 1000.0f);
        
        // Calculate velocity (v = Q/A)
        float velocity = flowRateM3S / PIPE_AREA;
        
        // Calculate pressure using simplified Bernoulli's equation
        // We assume P₀ = 175000 Pa (max pressure)
        float maxPressure = 175000.0f;
        float dynamicPressure = 0.5f * DENSITY * velocity * velocity;
        
        return maxPressure - dynamicPressure;
    }
    
    /**
     * Detect if there is a leak in the pipeline
     * 
     * @param flowRates Array of flow rates
     * @return Leak section (0 = no leak, 1 = between sensors 1-2, 2 = between sensors 2-3, 3 = multiple)
     */
    public static int detectLeak(float[] flowRates) {
        if (flowRates == null || flowRates.length < 3) {
            return 0;
        }
        
        // Convert flow rates to pressures
        float[] pressures = new float[flowRates.length];
        for (int i = 0; i < flowRates.length; i++) {
            pressures[i] = calculatePressure(flowRates[i]);
        }
        
        // Check pressure differences
        float expectedDrop = (pressures[0] - pressures[2]) / 2.0f;
        float drop1 = pressures[0] - pressures[1];
        float drop2 = pressures[1] - pressures[2];
        
        // Calculate percentage differences
        float diff1 = Math.abs((drop1 - expectedDrop) / expectedDrop) * 100.0f;
        float diff2 = Math.abs((drop2 - expectedDrop) / expectedDrop) * 100.0f;
        
        // Determine leak section
        if (diff1 > LEAK_THRESHOLD && diff2 > LEAK_THRESHOLD) {
            return 3; // Multiple leaks
        } else if (diff1 > LEAK_THRESHOLD) {
            return 1; // Leak between sensors 1 and 2
        } else if (diff2 > LEAK_THRESHOLD) {
            return 2; // Leak between sensors 2 and 3
        } else {
            return 0; // No leak
        }
    }
    
    /**
     * Get leak section description
     * 
     * @param leakSection Leak section code (0, 1, 2, or 3)
     * @return Description of the leak section
     */
    public static String getLeakDescription(int leakSection) {
        switch (leakSection) {
            case 0:
                return "No leak detected";
            case 1:
                return "Leak detected between points 1 and 2";
            case 2:
                return "Leak detected between points 2 and 3";
            case 3:
                return "Multiple leaks detected";
            default:
                return "Unknown leak status";
        }
    }
    
    /**
     * Check if the flow rate differences indicate a leak
     * 
     * @param flowRates Array of flow rates
     * @return True if a leak is detected
     */
    public static boolean isLeakDetected(float[] flowRates) {
        return detectLeak(flowRates) > 0;
    }
}