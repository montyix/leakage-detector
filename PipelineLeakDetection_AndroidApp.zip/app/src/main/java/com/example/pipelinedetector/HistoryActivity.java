package com.example.pipelinedetector;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class HistoryActivity extends AppCompatActivity {

    private ListView listView;
    private TextView txtNoHistory;
    private Button btnClearAll;
    private ImageButton btnBack;
    
    // Sample data for demonstration
    private List<Map<String, String>> historyList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        
        // Initialize views
        listView = findViewById(R.id.list_history);
        txtNoHistory = findViewById(R.id.txt_no_history);
        btnClearAll = findViewById(R.id.btn_clear_all);
        btnBack = findViewById(R.id.btn_back);
        
        // Load history (in a real app, this would come from a database)
        loadSampleHistory();
        
        // Set up the adapter
        String[] from = new String[]{"date", "time", "status", "details"};
        int[] to = new int[]{R.id.txt_date, R.id.txt_time, R.id.txt_status, R.id.txt_details};
        
        SimpleAdapter adapter = new SimpleAdapter(this, historyList, 
                R.layout.history_item, from, to);
        listView.setAdapter(adapter);
        
        // Show/hide empty state message
        if (historyList.isEmpty()) {
            txtNoHistory.setVisibility(View.VISIBLE);
            btnClearAll.setEnabled(false);
        } else {
            txtNoHistory.setVisibility(View.GONE);
            btnClearAll.setEnabled(true);
        }
        
        // Set click listeners
        btnClearAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmClearHistory();
            }
        });
        
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
    
    private void loadSampleHistory() {
        // For demonstration purposes only
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
        
        Date now = new Date();
        
        // Add some sample entries for demonstration
        for (int i = 0; i < 5; i++) {
            Map<String, String> item = new HashMap<>();
            
            // Calculate a time in the past
            Date pastTime = new Date(now.getTime() - (i * 3600000)); // i hours ago
            
            item.put("date", dateFormat.format(pastTime));
            item.put("time", timeFormat.format(pastTime));
            
            // Alternate between leak and no leak
            if (i % 2 == 0) {
                item.put("status", "LEAK DETECTED");
                if (i % 4 == 0) {
                    item.put("details", "Leak between points 1 and 2");
                } else {
                    item.put("details", "Leak between points 2 and 3");
                }
            } else {
                item.put("status", "NO LEAK");
                item.put("details", "Normal operation");
            }
            
            historyList.add(item);
        }
    }
    
    private void confirmClearHistory() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Clear History");
        builder.setMessage(R.string.confirm_clear_history);
        builder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                clearHistory();
            }
        });
        builder.setNegativeButton(R.string.no, null);
        builder.show();
    }
    
    private void clearHistory() {
        // Clear the history list
        historyList.clear();
        
        // Update the adapter
        ((SimpleAdapter) listView.getAdapter()).notifyDataSetChanged();
        
        // Show the empty state message
        txtNoHistory.setVisibility(View.VISIBLE);
        btnClearAll.setEnabled(false);
        
        // Show a confirmation toast
        android.widget.Toast.makeText(this, R.string.history_cleared, android.widget.Toast.LENGTH_SHORT).show();
    }
}